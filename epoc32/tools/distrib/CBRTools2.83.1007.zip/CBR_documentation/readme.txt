To build CBR documentation using xbuild:

C:\>xbuild --auto-controlfiles --full --src-root=path\to\cbr\tools\docs --target-root=C:\temp\cbr-doc-output source

Explore within the target and locate the .hhp (HTML Help Project) file. Compile using HTML Help Workshop.

-- larryk 2006-03-30
