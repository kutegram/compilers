# Miscellaneous components.
default \\pixieshare\release_archive\misc	/mycompany/pixie/misc

# Components delivered by our company.
comp1	\\pixieshare\release_archive\mycompany	/mycompany/pixie
comp2	\\pixieshare\release_archive\mycompany	/mycompany/pixie

# Components delivered by other companies.
comp3	\\pixieshare\release_archive\company_x	/company_x/pixie
comp4	\\pixieshare\release_archive\company_y	/company_y/pixie

