# Symbian::CBR::ApplyDelta.pm
#
# Copyright (c) 2007 Symbian Software Ltd. All rights reserved.
#

package Symbian::CBR::ApplyDelta;

use File::Basename;
use FindBin qw($Bin);
use File::Spec;
use Symbian::CBR::Component::Manifest;
use Symbian::CBR::DeltaRelease::Manifest qw(META_FILES DELTA_MANIFEST_FILE);
use ExportData;
use EnvDb;
use Utils;
use File::Path;
use XML::Simple;
use File::Copy;
use Carp;



sub new {
  my $pkg = shift;
  my $iniData = shift;
  my $verbose = shift;
  my $self;
  $self->{iniData} = $iniData;
  $self->{verbose} = $verbose;
  bless $self, $pkg;
  return $self;
}


sub ReconstructEnv {
  my $self = shift;
  my $zipFile = shift;
  my $overwrite = shift;

  $self->{deltaManifest} = Symbian::CBR::DeltaRelease::Manifest->new($self->{verbose});
  Utils::InitialiseTempDir($self->{iniData});
  $self->{deltaDir} = Utils::TempDir();

  my $deltaManifestFile = File::Spec->catfile($self->{deltaDir}, DELTA_MANIFEST_FILE );
  print "Extracting delta release package.\n";
  eval {Utils::Unzip($zipFile,$self->{deltaDir},0,1);};
  croak "Error: Couldn't Extract File $zipFile $@\n" if($@);
  #Read delta manifest file.

  $self->{deltaManifest}->LoadManifest($deltaManifestFile);
  my $referenceBaseline = $self->{deltaManifest}->GetReferenceBaselineComp();
  my $referenceVersion = $self->{deltaManifest}->GetReferenceBaselineVer();
  my $destination =  $self->{iniData}->PathData->LocalArchivePathForExistingComponent($referenceBaseline, $referenceVersion);
  croak "Error: Reference baseline $referenceBaseline $referenceVersion does not exist.\n" unless (defined $destination);
  my $index = index($destination, $referenceBaseline);
  $destination = substr($destination, 0, ($index));
  foreach  my $comp (sort keys %{$self->{deltaManifest}->ListAllComponents()}) {
    my $compStatus = $self->{deltaManifest}->GetCompStatus($comp);
    if ($compStatus eq "modified") {
      $self->ReconstructComp($comp, $destination, $overwrite); #Reconstruct modified component.
    }
    elsif ($compStatus eq "added") {
      $self->CopyCompToBaseline($comp, $destination, $overwrite); #Directly copy component to baseline.
    }
  }
  rmtree($self->{deltaDir}) or print "Warning: Couldn't delete temp directory ".$self->{deltaDir}.".\n";
}

sub CopyCompToBaseline {
  my $self = shift;
  my $comp = shift;
  my $destination = shift;
  my $overwrite = shift;
  my $tempDir = Utils::TempDir();
  print "$comp is newly added to the baseline.\n";
  my $tempNewCompPath = File::Spec->catfile($self->{deltaDir},"new", $comp);
  my $nomVersion = $self->{deltaManifest}->GetCompNominatedVer($comp);
  my $archiveCompPath = File::Spec->catdir($destination, $comp, $nomVersion);
  if (-d $archiveCompPath and !$overwrite) {
    croak "Error: $comp is already exists. Please use -o option to overwrite.\n";
  }
  mkpath($archiveCompPath) unless (-d $archiveCompPath);
  foreach my $thisFile (@{Utils::ReadDir($tempNewCompPath)}) {
    my $thisTempFile = File::Spec->catfile($tempNewCompPath, $thisFile);
    my $thisArchivepFile = File::Spec->catfile($archiveCompPath, $thisFile);
	if (-e $thisArchivepFile) {
      print "Overwriting $thisFile.\n " if ($self->{verbose});	
      unlink($thisArchivepFile) or croak "Error: Couldn't delete $thisArchivepFile : $!\n";	
    }	  
    copy($thisTempFile, $thisArchivepFile) or croak "Error: Couldn't copy file from $thisTempFile to $thisArchivepFile.\n";
  }
}

sub ReconstructComp {
  my $self = shift;
  my $comp = shift;
  my $destination = shift;
  my $overwrite = shift;

  my $refVersion =  $self->{deltaManifest}->GetCompReferenceVer($comp);
  my $nomVersion = $self->{deltaManifest}->GetCompNominatedVer($comp);
  print "Reconstructing $comp component.\n";
  my $refCompVer = File::Spec->catdir($destination, $comp, $refVersion);
  my $nomCompVer = File::Spec->catdir($destination, $comp, $nomVersion);
  if (-d $nomCompVer and !$overwrite) {
    croak "Error: $comp of $nomVersion version is already exists. Please use -o option to overwrite.\n";
  }
  if (-d $nomCompVer) {
    print "Overwriting $comp\n" if($self->{verbose});
    rmtree($nomCompVer) or croak "Error: Couldn't delete $nomCompVer directory\n";
  }
  mkpath($nomCompVer);
  #Make copy of reference version.
  foreach my $thisFile (@{Utils::ReadDir($refCompVer)}) {
    my $thisRefFile = File::Spec->catfile($refCompVer, $thisFile);
    my $thisNomFile = File::Spec->catfile($nomCompVer, $thisFile);
    copy($thisRefFile, $thisNomFile) or croak "Error: Couldn't copy file from $thisRefFile  to $thisNomFile. $!\n";
  }

  #Reconstruct modified zip files, copy newly added zip files and delete deleted zip files.
  foreach  my $zipfile (keys  %{$self->{deltaManifest}->GetZipFilesForComp($comp)}) {
    my $zipStatus = $self->{deltaManifest}->GetZipStatus($comp, $zipfile);
    my $nomZipFile = File::Spec->catfile($nomCompVer, $zipfile);
    if ($zipStatus eq "modified") {
      $self->ReconstructZipFile($comp, $zipfile, $nomCompVer); #If zip file is modified, then reconstruct it.
    }
    elsif ($zipStatus eq "added") {
      my $tempZipFile = File::Spec->catfile($tempDir,"modified","addedZips",$comp,$zipfile);
      if (-e $nomZipFile) {
        print "Overwriting $nomZipFile.\n " if ($self->{verbose});
        unlink($nomZipFile) or croak "Error: Couldn't delete $nomZipFile : $!\n";
      }
      copy($tempZipFile, $nomZipFile) or croak "Error: Couldn't copy $tempZipFile to $nomZipFile. $!\n";
    }
    elsif ($zipStatus eq "deleted") {
      if (-e $nomZipFile) {
        unlink($nomZipFile) or croak "Error: Couldn't delete $nomZipFile : $!\n"
      }
    }
    elsif ($zipStatus eq "identical") {
      print "$zipfile is not modified.\n" if($self->{verbose} > 1);
    }
    else {
      croak "Error: Unknown zip file status \"$zipStatus\" for $zipfile of $comp component in delta manifest file.\n";
    }
  }
  #Reconstruct reldata, manifest.xml and exports.txt files.
  my $deltaFilePath = File::Spec->catdir($self->{deltaDir}, META_FILES);
  foreach my $metafile (keys  %{$self->{deltaManifest}->GetMetaFiles($comp)}) {
    my $nomFile = File::Spec->catfile($nomCompVer, $metafile);
    my $deltaFile = $comp."_".$metafile;
    $deltaFile = File::Spec->catfile($deltaFilePath, $deltaFile);
	unlink ($nomFile) if (-e $nomFile);
    print "Copying $metafile.\n" if( -e $metafile and $self->{verbose});
	copy($deltaFile, $nomFile) or croak "Error: Couldn't Copy file from $deltaFile  to $nomFile. $!\n";
  }
}


sub ReconstructZipFile {
  my $self = shift;
  my $comp = shift;
  my $zipfile = shift;
  my $nomCompVer = shift;
  
  my $nomZipFile = File::Spec->catfile($nomCompVer, $zipfile);
  my $tempCompPath = File::Spec->catdir($self->{deltaDir},"TempComps",$comp);
  mkpath ($tempCompPath) unless(-d $tempCompPath);
  my $tempCompZipFile = File::Spec->catdir($self->{deltaDir}, "TempZips");
  mkpath($tempCompZipFile) unless(-d $tempCompZipFile);
  $tempCompZipFile = File::Spec->catdir($tempCompZipFile, $zipfile);
  #Move zip file to temporary location.
  move($nomZipFile, $tempCompZipFile) or croak "Error: Couldn't move $zipfile to temp directory. $!\n";
  print "Extracting $zipfile file.\n" if($self->{verbose} > 1);
  Utils::Unzip($tempCompZipFile,$tempCompPath,0,1);
  unlink($tempCompZipFile) or croak "Error: Couldn't delete $tempCompZipFile : $!\n";

  foreach my $file (keys %{$self->{deltaManifest}->GetFilesForZip($comp, $zipfile)}) {
    my $fileStatus = $self->{deltaManifest}->GetFileStatus($comp, $zipfile, $file);
	my $type = $self->{deltaManifest}->GetFileType($comp, $zipfile, $file );
    if ($fileStatus eq "added") {
      my $deltaFilePath = File::Spec->catfile($self->{deltaDir},"modified",$file);
      my $tempCompFilePath = File::Spec->catfile($tempCompPath,$file);
      print "Copying $file\n" if($self->{verbose});
	  my $tempFilePath = dirname ($tempCompFilePath);
	  unless (-e $tempFilePath) {
	    mkpath ($tempFilePath) or croak "Error: Unable to create $tempFilePath path.\n";
	  }
      croak "Error: $deltaFilePath file doesn't exists.\n" unless (-e $deltaFilePath);
	  copy($deltaFilePath, $tempCompFilePath) or croak "Error: Couldn't copy file from $deltaFilePath to $tempCompFilePath\n";
    }
    elsif ($fileStatus eq "modified") {
      if ($type eq "file") {
        my $deltaFilePath = File::Spec->catfile($self->{deltaDir},"modified",$file);
        my $tempCompFilePath = File::Spec->catfile($tempCompPath,$file);
        if (-e $tempCompFilePath) {
          unlink($tempCompFilePath) or croak "Error: Couldn't delete $tempCompFilePath : $!\n";
        }
        my $tempFilePath = dirname ($tempCompFilePath);
        unless (-e $tempFilePath) {
          mkpath ($tempFilePath) or croak "Error: Unable to create $tempFilePath path.\n";
        }		  
        croak "Error: $deltaFilePath file doesn't exists.\n" unless (-e $deltaFilePath);
        copy ($deltaFilePath, $tempCompFilePath) or croak "Error_223: Couldn't copy file from $deltaFilePath to $tempCompFilePath\n";
      }
      elsif ($type eq "delta") {
        my $tempCompFilePath = File::Spec->catfile($tempCompPath,$file);
        my $deltaFile = $file.".delta";
        $deltaFile = File::Spec->catfile($self->{deltaDir}, "modified", $deltaFile);
        $self->ReconstructFile($tempCompFilePath, $deltaFile, $tempCompFilePath);
      }
      else {
        croak "Error: Unknown file type \"$type\" in delta manifest file.\n";
      }
    }
    elsif ($fileStatus eq "deleted") {
      my $tempCompFilePath = File::Spec->catfile($tempCompPath,$file);
      unlink($tempCompFilePath) or croak "Error: Couldn't delete $tempCompFilePath : $!\n";
    }
    else {
      croak "Error: Unknown file status \"$fileStatus\" for \"$file\" file.\n";
    }
  }
  #Pack all files of a zipfile to form a category.zip file.
  my @allFiles;
  my @filesToBeZipped;
  Utils::ListAllFiles($tempCompPath, \@allFiles);
  foreach  my $thisFile (@allFiles) {
    my $file = substr($thisFile, (length($tempCompPath)+1));
    push @filesToBeZipped, $file;
  }
  Utils::ZipList( $nomZipFile, \@filesToBeZipped, $self->{verbose}, undef,$tempCompPath);
  rmtree ($tempCompPath) or croak "Error: Couldn't delete $tempCompPath directory.\n"; 
}

sub ReconstructFile {
  my $self = shift;
  my $referenceFile = shift;
  my $deltaFilePath = shift;
  my $destination = shift;

  my $destinationDir = dirname($destination);
  mkpath($destinationDir) unless(-d $destinationDir);
  print "Reconstructing ".basename($referenceFile)." file.\n" if($self->{verbose} > 1);
  my $status = system "zdu \"$referenceFile\" \"$deltaFilePath\"  \"$destination\"" ;
  if( $status != 0 ) {
    $status = system "zdu" ;
    $! = $? >> 8;
    if( $status != 0 ) {
      print "Error: The zdelta tool is not installed. Please install zdelta.\n";
      croak;
    }
    else {
      print "Error: The zdelta tool is not installed properly. Please install zdelta once again.\n";
      croak;
    }
  }
}

1;

__END__


=head1 NAME

Symbian::CBR::ApplyDelta.pm - Reconstructs the nominated baseline using deltas and reference version of baseline.

=head2 new

Expects to be passed an C<IniData> reference and verbosity level. Creates an ApplyDelta object. 

=head2 ReconstructEnv

Expects to be passed a delta zip file path, a destination archive where the environment is to be created, and an overwrite flag specifying whether existing components should be overwritten or not. It makes use of the delta zip file and a reference baseline (specified by the delta manifest file) and reconstructs the originally nominated baseline.

=head2 ReconstructComp

Expects to be passed a component name, a destination and an overwrite flag specifying whether existing component should be overwritten or not. It makes use of the delta for a component and a reference version of a component (specified by the delta manifest file) and reconstructs the originally nominated version of a component.

=head2 ReconstructFile

Expects to be passed a reference file, path to a delta file and a destination path. Makes use of the zdelta third party tool to reconstruct the originally nominated version of the file from the inputs.

=head1 KNOWN BUGS

None.

=head1 COPYRIGHT

Copyright (c) 2007 Symbian Software Ltd. All rights reserved.

=cut
