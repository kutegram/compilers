# RemoteSite::FTP::Proxy::Experimental.pm
#
# Copyright (c) 2000-2004 Symbian Ltd. All rights reserved.
#

package RemoteSite::FTP::Proxy::Experimental;

use strict;

use RemoteSite::FTP::Experimental;
use RemoteSite::FTP::Proxy;
use vars qw(@ISA);
@ISA=("RemoteSite::FTP::Experimental", "RemoteSite::FTP::Proxy");

1;

=head1 NAME

RemoteSite::FTP::Experimental::Proxy.pm - Access a remote FTP site.

=head1 DESCRIPTION

This class differs from C<RemoteSite::FTP::Proxy> only in using a different mechanism for listing the contents of directories on FTP sites.

=head1 KNOWN BUGS

None

=head1 COPYRIGHT

Copyright (c) 2000-2004 Symbian Ltd. All rights reserved.

=cut
